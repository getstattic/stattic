#!/usr/bin/env python3
"""
Performance test script for Stattic PyPI package.
Tests both small and large workloads to verify concurrency fixes.
"""

import os
import sys
import time
import shutil
from pathlib import Path

# Add the stattic_pkg to Python path
sys.path.insert(0, os.path.dirname(__file__))

from stattic_pkg.core import Stattic

def cleanup_output(output_dir):
    """Clean up output directory before test."""
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)

def test_small_workload():
    """Test with small workload (2 pages + 5 posts = 7 files)."""
    print("=" * 60)
    print("TESTING SMALL WORKLOAD (2 pages + 5 posts = 7 files)")
    print("=" * 60)
    
    output_dir = "output_small"
    cleanup_output(output_dir)
    
    start_time = time.time()
    
    try:
        generator = Stattic(
            content_dir='content',
            templates_dir='stattic_pkg/templates',
            output_dir=output_dir,
            posts_per_page=5,
            sort_by='date',
            fonts=['Quicksand'],
            site_url='https://test.stattic.site'
        )
        
        generator.build()
        
    except Exception as e:
        print(f"Error during small workload test: {e}")
        return None
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"✅ Small workload completed in {duration:.3f} seconds")
    return duration

def test_large_workload():
    """Test with large workload (~1000 posts)."""
    print("=" * 60)
    print("TESTING LARGE WORKLOAD (~1000 posts)")
    print("=" * 60)
    
    # First, we need to temporarily move the 1k posts to the main posts directory
    posts_dir = Path("content/posts")
    posts_1k_dir = Path("content/posts_1k")
    posts_backup_dir = Path("content/posts_backup")
    
    # Backup original posts
    if posts_dir.exists():
        shutil.move(str(posts_dir), str(posts_backup_dir))
    
    # Move 1k posts to main posts directory
    shutil.move(str(posts_1k_dir), str(posts_dir))
    
    output_dir = "output_large"
    cleanup_output(output_dir)
    
    start_time = time.time()
    
    try:
        generator = Stattic(
            content_dir='content',
            templates_dir='stattic_pkg/templates',
            output_dir=output_dir,
            posts_per_page=10,
            sort_by='date',
            fonts=['Quicksand'],
            site_url='https://test.stattic.site'
        )
        
        generator.build()
        
    except Exception as e:
        print(f"Error during large workload test: {e}")
        return None
    
    finally:
        # Restore original directory structure
        shutil.move(str(posts_dir), str(posts_1k_dir))
        if posts_backup_dir.exists():
            shutil.move(str(posts_backup_dir), str(posts_dir))
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"✅ Large workload completed in {duration:.3f} seconds")
    return duration

def main():
    """Run performance tests."""
    print("Stattic PyPI Package Performance Test")
    print("Testing concurrency fixes for adaptive processing")
    print()
    
    # Change to the stattic directory
    os.chdir('/Users/robertdevore/Documents/Stattic-2k25/stattic')
    
    # Test small workload
    small_duration = test_small_workload()
    
    print("\n")
    
    # Test large workload
    large_duration = test_large_workload()
    
    print("\n" + "=" * 60)
    print("PERFORMANCE TEST SUMMARY")
    print("=" * 60)
    
    if small_duration and large_duration:
        print(f"Small workload (7 files):  {small_duration:.3f} seconds")
        print(f"Large workload (1000 files): {large_duration:.3f} seconds")
        print(f"Performance ratio: {large_duration/small_duration:.1f}x slower for large workload")
        
        # Check if multiprocessing was used appropriately
        if small_duration < 2.0:  # Should be fast with multiprocessing
            print("✅ Small workload performance looks good")
        else:
            print("⚠️  Small workload seems slow - check if multiprocessing is being used")
            
        if large_duration < 60.0:  # Should complete within reasonable time
            print("✅ Large workload performance looks good")
        else:
            print("⚠️  Large workload seems slow - check multiprocessing efficiency")
    else:
        print("❌ One or more tests failed")

if __name__ == "__main__":
    main()
