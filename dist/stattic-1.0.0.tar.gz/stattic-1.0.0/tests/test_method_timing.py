#!/usr/bin/env python3
"""
Performance test for individual build methods.
"""

import os
import sys
import time
from pathlib import Path

# Add the stattic_pkg to Python path
sys.path.insert(0, '/Users/robertdevore/Documents/Stattic-2k25/stattic')

from stattic_pkg.core import Stattic

def test_individual_methods():
    """Test each build method individually to find the bottleneck."""
    print("Testing individual build methods...")
    
    os.chdir('/Users/robertdevore/Documents/Stattic-2k25/stattic')
    
    # Initialize Stattic instance
    generator = Stattic(
        content_dir='content',
        templates_dir='stattic_pkg/templates',
        output_dir='output_timing_test',
        posts_per_page=5,
        sort_by='date',
        fonts=['Quicksand'],
        site_url='https://test.stattic.site'
    )
    
    methods_to_test = [
        ('copy_assets_to_output', generator.copy_assets_to_output),
        ('download_google_fonts', generator.download_google_fonts),
        ('build_posts_and_pages', generator.build_posts_and_pages),
        ('build_blog_page', generator.build_blog_page),
        ('build_index_page', generator.build_index_page),
        ('build_404_page', generator.build_404_page),
        ('generate_rss_feed', lambda: generator.generate_rss_feed(generator.site_url, None)),
        ('generate_xml_sitemap', lambda: generator.generate_xml_sitemap(generator.site_url)),
        ('generate_robots_txt', lambda: generator.generate_robots_txt('public')),
        ('generate_llms_txt', lambda: generator.generate_llms_txt(None, None)),
    ]
    
    total_time = 0
    
    for method_name, method in methods_to_test:
        print(f"\nTesting {method_name}...")
        start_time = time.time()
        
        try:
            method()
            end_time = time.time()
            duration = end_time - start_time
            total_time += duration
            print(f"✅ {method_name}: {duration:.3f} seconds")
        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time
            total_time += duration
            print(f"❌ {method_name}: {duration:.3f} seconds (ERROR: {e})")
    
    print(f"\nTotal time: {total_time:.3f} seconds")
    print(f"Posts: {len(generator.posts)}")

if __name__ == "__main__":
    test_individual_methods()
