#!/usr/bin/env python3
"""
Performance comparison between old stattic.py and new stattic_pkg.
"""

import os
import sys
import time
import shutil
import subprocess
from pathlib import Path

def cleanup_output(output_dir):
    """Clean up output directory before test."""
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)

def test_old_stattic_small():
    """Test old stattic.py with small workload."""
    print("Testing OLD stattic.py (small workload)...")
    
    old_dir = "/Users/robertdevore/Desktop/stattic-old/stattic"
    cleanup_output(f"{old_dir}/output")
    
    start_time = time.time()
    
    # Run old stattic.py
    result = subprocess.run([
        "python3", "stattic.py",
        "--content", "content",
        "--templates", "templates", 
        "--output", "output",
        "--site-url", "https://test.stattic.site"
    ], cwd=old_dir, capture_output=True, text=True)
    
    end_time = time.time()
    duration = end_time - start_time
    
    if result.returncode == 0:
        print(f"✅ Old stattic.py (small): {duration:.3f} seconds")
        return duration
    else:
        print(f"❌ Old stattic.py failed: {result.stderr}")
        return None

def test_new_stattic_small():
    """Test new stattic_pkg with small workload."""
    print("Testing NEW stattic_pkg (small workload)...")
    
    new_dir = "/Users/robertdevore/Documents/Stattic-2k25/stattic"
    cleanup_output(f"{new_dir}/output")
    
    os.chdir(new_dir)
    sys.path.insert(0, new_dir)
    
    from stattic_pkg.core import Stattic
    
    start_time = time.time()
    
    try:
        generator = Stattic(
            content_dir='content',
            templates_dir='stattic_pkg/templates',
            output_dir='output',
            posts_per_page=5,
            sort_by='date',
            fonts=['Quicksand'],
            site_url='https://test.stattic.site'
        )
        generator.build()
        
    except Exception as e:
        print(f"❌ New stattic_pkg failed: {e}")
        return None
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"✅ New stattic_pkg (small): {duration:.3f} seconds")
    return duration

def main():
    """Compare performance between old and new implementations."""
    print("Performance Comparison: Old stattic.py vs New stattic_pkg")
    print("=" * 60)
    
    # Test small workload with both implementations
    old_duration = test_old_stattic_small()
    print()
    new_duration = test_new_stattic_small()
    
    print("\n" + "=" * 60)
    print("COMPARISON RESULTS")
    print("=" * 60)
    
    if old_duration and new_duration:
        improvement = ((old_duration - new_duration) / old_duration) * 100
        if improvement > 0:
            print(f"✅ New implementation is {improvement:.1f}% FASTER")
        else:
            print(f"⚠️  New implementation is {abs(improvement):.1f}% SLOWER")
        
        print(f"Old stattic.py:  {old_duration:.3f}s")
        print(f"New stattic_pkg: {new_duration:.3f}s")
        print(f"Difference: {new_duration - old_duration:+.3f}s")
    else:
        print("❌ Could not complete comparison due to test failures")

if __name__ == "__main__":
    main()
