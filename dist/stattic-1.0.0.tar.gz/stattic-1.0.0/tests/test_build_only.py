#!/usr/bin/env python3
"""
Focused performance test for build_posts_and_pages method.
"""

import os
import sys
import time
from pathlib import Path

# Add the stattic_pkg to Python path
sys.path.insert(0, '/Users/robertdevore/Documents/Stattic-2k25/stattic')

from stattic_pkg.core import Stattic

def test_build_performance():
    """Test just the build_posts_and_pages performance."""
    print("Testing build_posts_and_pages performance...")
    
    os.chdir('/Users/robertdevore/Documents/Stattic-2k25/stattic')
    
    # Initialize Stattic instance
    generator = Stattic(
        content_dir='content',
        templates_dir='stattic_pkg/templates',
        output_dir='output_perf_test',
        posts_per_page=5,
        sort_by='date',
        fonts=['Quicksand'],
        site_url='https://test.stattic.site'
    )
    
    # Time just the posts and pages building
    print(f"Processing {len(generator.get_markdown_files('content/posts'))} posts and {len(generator.get_markdown_files('content/pages'))} pages...")
    
    start_time = time.time()
    generator.build_posts_and_pages()
    end_time = time.time()
    
    duration = end_time - start_time
    print(f"build_posts_and_pages completed in {duration:.3f} seconds")
    print(f"Posts generated: {generator.posts_generated}")
    print(f"Pages generated: {generator.pages_generated}")
    
    return duration

if __name__ == "__main__":
    test_build_performance()
