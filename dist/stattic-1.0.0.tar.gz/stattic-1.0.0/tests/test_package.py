#!/usr/bin/env python3
"""
Test script for the package version of Stattic.
"""

import sys
import os
import time

# Add the current directory to the path so we can import stattic_pkg
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from stattic_pkg.core import Stattic

def main():
    """Test the package version performance."""
    print("=== Testing Package Version ===")
    
    try:
        start_time = time.time()
        
        # Initialize Stattic with default settings
        print("Initializing Stattic...")
        stattic = Stattic()
        
        # Build the site using the build method directly
        print("Building site...")
        stattic.build()
        
        end_time = time.time()
        build_time = end_time - start_time
        
        print(f"Package build completed in {build_time:.6f} seconds")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("Script starting...")
    main()
    print("Script finished.")
